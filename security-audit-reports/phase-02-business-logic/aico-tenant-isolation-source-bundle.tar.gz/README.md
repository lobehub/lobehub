# Tenant Isolation — Prepared Source Kit

Self-contained snapshot of Aico Organization tenant-isolation code for Phase 2 security audit.

| Field | Value |
| --- | --- |
| **Location** | `security-audit-reports/phase-02-business-logic/tenant-isolation-source/` |
| **Live repo** | Project root (same relative paths) |
| **Archive** | `../aico-tenant-isolation-source-bundle.tar.gz` |

> **Important:** This tree is a **read-only audit snapshot**. Apply fixes in the live repository. Vitest excludes `security-audit-reports/**` so snapshot tests are never executed.

## Start here

1. `../03-tenant-isolation-security.md` — findings
2. `../03-tenant-isolation-security-retest.md` — retest status
3. `../00-source-access.md` — clone / access notes

## Layout

Mirrors live repo paths under `apps/`, `packages/`, `src/`, plus migration `0137_aico_member_budgets_org_id.sql`.

## Verify in the live repo

```bash
bun run check --test apps/server/src/routers/lambda/__tests__/aico.rbacIdor.test.ts
```
